﻿function renderRXLayer(rxLayerDraw) {


    var ellipse = rxLayerDraw.ellipse(200, 100)

}

function renderTXLayer(txLayerDraw) {

}

function renderDielectric(dielectricLayerDraw) {
    var ell = dielectricLayerDraw.ellipse(200, 100);
}