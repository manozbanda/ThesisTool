Moduluar source of the Multi-Touch Design Tool
