var usb = require('usb');
var fs = require('fs');
var csv = require('ya-csv');
var os = require('os');
var reader = csv.createCsvFileReader('write_commands.csv', {
    'separator': ',',
    'quote': '"',
    'escape': '"',       
    'comment': '',
});


function readTouchEndPoints(touchEndPoints){
	touchEndpoints[0].startPoll(1 , 64);

	touchEndpoints[0].on('data', function(data){
	console.log(data);

	});
	touchEndpoints[0].on('error', function(error){
	console.log(error);

	});
}

function readRawMutualData(reader, dataToBeSent, endpoints){
	reader.addListener('data', function(data){
		for(var i = 0 ; i < 64; i++){
			
			dataToBeSent[i] = data[i];
			
			
		}
		
		endpoints[1].transfer(dataToBeSent, function(err, data){
		if(!err){
		}
			else{
				console.log(error);
			}

		});


	});
	
	endpoints[0].startPoll(1 , 64);
	endpoints[0].on('data', function(data){
	//console.log(data);
	for(var i = 0 ; i < 64; i++){
		
		if(data[i] == 0xc3){
			if( (data[i + 1] <= 0x1a) && (data[i + 2] <= 0x13)){
				var rxLocation = data[i + 1];
				var txLocation = data[i + 2];
				var LSB, MSB;
				if(data[ i + 3] != undefined)
					LSB = data[i + 3].toString(16);
				if(data[i + 4] != undefined)
					MSB = data[i + 4].toString(16);
				var value = LSB + MSB;
				console.log("RX: " + rxLocation + " TX: " + txLocation + 
							" LSB : " + LSB + " MSB: " + MSB + " Data: " + value);
				console.log(os.EOL);
			}
		
		}
		//fs.appendFile('dataLog.txt', data[i] + " ", function(err){

		//	if(err)
		//	console.log(err);
		//});
	}
	//console.log("");
	

	});
}

//console.log(usb.getDeviceList());

var mtchController = usb.findByIds(1240, 2517);
//console.log(mtchController);


mtchController.open();

var endpoints = mtchController.interfaces[1].endpoints;
//console.log(endpoints);

var touchEndpoints = mtchController.interfaces[0].endpoints;
console.log(touchEndpoints);


if(mtchController.interfaces[0].isKernelDriverActive()){
	console.log("Touch Data Endpoints Interface Busy");
	mtchController.interfaces[0].detachKernelDriver();
	mtchController.interfaces[0].claim();
}

if(mtchController.interfaces[1].isKernelDriverActive()){
	console.log("Raw data endpoints busy");
	mtchController.interfaces[1].detachKernelDriver();
	mtchController.interfaces[1].claim();

}


mtchController.interfaces[0].claim();
mtchController.interfaces[1].claim();

endpoints[0].transferType = usb.LIBUSB_TRANSFER_TYPE_BULK;
endpoints[1].transferType = usb.LIBUSB_TRANSFER_TYPE_BULK;

touchEndpoints[0].transferType = usb.LIBUSB_TRANSFER_TYPE_BULK;

var dataToBeSent = new Uint8Array(64);
/*dataToBeSent[0] = 0x05;
dataToBeSent[1] = 0x03;
dataToBeSent[2] = 0x0b;
dataToBeSent[3] = 0xe0;

dataToBeSent[4] = 0x80;
dataToBeSent[5] = 0x00;

dataToBeSent[6] = 0x00;
dataToBeSent[7] = 0x00;
dataToBeSent[8] = 0x00;
dataToBeSent[9] = 0x00;

dataToBeSent[10] = 0xff;
dataToBeSent[11] = 0xff;
dataToBeSent[12] = 0xff;
dataToBeSent[13] = 0xff;

endpoints[1].transfer(dataToBeSent, function(err, data){
	if(!err){
	}
	else{
	 console.log(error);
	}

});

endpoints[0].transfer(64, function(err, data){
	
	 console.log(data);
	

});*/

/*reader.addListener('data', function(data){
	for(var i = 0 ; i < 64; i++){
		
		dataToBeSent[i] = data[i];
		
		
	}
	
	//console.log(dataToBeSent);	
	endpoints[1].transfer(dataToBeSent, function(err, data){
	if(!err){
	}
		else{
	 		console.log(error);
		}

	});


});*/

//readTouchEndPoints(touchEndpoints);
readRawMutualData(reader, dataToBeSent, endpoints);


/*endpoints[0].startPoll(1 , 64);
endpoints[0].on('data', function(data){
	//console.log(data);
	for(var i = 0 ; i < 64; i++){
		
		if(data[i] == 0xc3){
			if( (data[i + 1] <= 0x1a) && (data[i + 2] <= 0x13)){
				var rxLocation = data[i + 1];
				var txLocation = data[i + 2];
				var LSB, MSB;
				if(data[ i + 3] != undefined)
					LSB = data[i + 3].toString(16);
				if(data[i + 4] != undefined)
					MSB = data[i + 4].toString(16);
				var value = LSB + MSB;
				console.log("RX: " + rxLocation + " TX: " + txLocation + 
							" LSB : " + LSB + " MSB: " + MSB + " Data: " + value);
				console.log(os.EOL);
			}
		
		}
		//fs.appendFile('dataLog.txt', data[i] + " ", function(err){

		//	if(err)
		//	console.log(err);
		//});
	}
	//console.log("");
	

});*/
