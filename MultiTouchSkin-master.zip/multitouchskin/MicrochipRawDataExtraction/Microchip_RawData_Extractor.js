var csv_parser = require('csv-parse');
var csvWriter = require('csv-write-stream');
var fs = require('fs');


var usb = require('usb');
var events = require('events');
var eventEmitter = new events.EventEmitter();

var mtchController = usb.findByIds(1240, 2517);
console.log(mtchController);


mtchController.open();

var endpoints = mtchController.interfaces[1].endpoints;
var touchEndpoints = mtchController.interfaces[0].endpoints;

endpoints[1].transferType = usb.LIBUSB_TRANSFER_TYPE_BULK;
mtchController.interfaces[0].claim();
mtchController.interfaces[1].claim();
endpoints[1].transferType = 2;

var dataCommand = new Uint8Array(64);
var parser = csv_parser({delimiter: ","}, function(err, data){
    data.forEach( function(line){
        
        for(var i = 0 ;i < line.length; i++){
            dataCommand[i] = line[i];
           
        }
        endpoints[1].transfer(dataCommand, function(err, data) {
            if (!err) {
                // console.log(dataToBeSent);
            } else {
                console.log(err);
            }
        });     
    });
    console.log("\n");
});

endpoints[0].startPoll(5, 64);
endpoints[0].on('data', function(data) {

    
   // console.log("ONDATA");
    console.log(data);    
   /* fs.appendFile('dataLog.txt', data , function (err) {
        if (err) throw err;
       // console.log('Saved!');
      });*/
    /*for(var x = 0 ; x < data.length; x++){
        /*fs.writeFile("dataLog.txt", data[x].toString(16) + "\t", function(err){
            if(err){
                return console.log(err);
            }
        });
        fs.appendFile('dataLog.txt', data[x].toString(16) + "\t", function (err) {
            if (err) throw err;
           // console.log('Saved!');
          });
    };*/
    /*fs.appendFile('dataLog.txt', "\n", function (err) {
        if (err) throw err;
       // console.log('Saved!');
      });*/
    

});


var records = fs.createReadStream('./data/write_commands.csv').pipe(parser);






