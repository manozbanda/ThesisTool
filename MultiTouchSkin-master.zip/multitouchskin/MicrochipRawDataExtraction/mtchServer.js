var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var express = require('express');

var usb = require('usb');
var fs = require('fs');
var csv = require('ya-csv');
var os = require('os');
var reader = csv.createCsvFileReader('write_commands.csv', {
    'separator': ',',
    'quote': '"',
    'escape': '"',       
    'comment': '',
});

var dataToBeSent = new Uint8Array(64);


app.use('/images', express.static(__dirname + '/images'));

function readTouchEndPoints(touchEndPoints){
	touchEndpoints[0].startPoll(1 , 64);

	touchEndpoints[0].on('data', function(data){
	console.log(data);

	});
	touchEndpoints[0].on('error', function(error){
	console.log(error);

	});
}

function readRawMutualData(reader, dataToBeSent, endpoints){
	reader.addListener('data', function(data){
		for(var i = 0 ; i < 64; i++){
			dataToBeSent[i] = data[i];	
		}
		
		endpoints[1].transfer(dataToBeSent, function(err, data){
		if(!err){
		}
			else{
				console.log(error);
			}

		});


	});
	
	endpoints[0].startPoll(1 , 64);
	endpoints[0].on('data', function(data){
	dataToBeSent = data;
	
	//console.log(dataToBeSent);
	io.sockets.emit('raw data', JSON.stringify(data));
	console.log(JSON.stringify(data));	
	});
}

var mtchController = usb.findByIds(1240, 2517);
mtchController.open();
var endpoints = mtchController.interfaces[1].endpoints;
var touchEndpoints = mtchController.interfaces[0].endpoints;
console.log(touchEndpoints);

//detach the system USB driver if the USB interfaces are busy
if(mtchController.interfaces[0].isKernelDriverActive()){
	console.log("Touch Data Endpoints Interface Busy");
	mtchController.interfaces[0].detachKernelDriver();
	mtchController.interfaces[0].claim();
}


if(mtchController.interfaces[1].isKernelDriverActive()){
	console.log("Raw data endpoints busy");
	mtchController.interfaces[1].detachKernelDriver();
	mtchController.interfaces[1].claim();

}

//claim the USB interfaces
mtchController.interfaces[0].claim();
mtchController.interfaces[1].claim();

endpoints[0].transferType = usb.LIBUSB_TRANSFER_TYPE_BULK;
endpoints[1].transferType = usb.LIBUSB_TRANSFER_TYPE_BULK;

touchEndpoints[0].transferType = usb.LIBUSB_TRANSFER_TYPE_BULK;

reader.addListener('data', function(data){
	for(var i = 0 ; i < 64; i++){
		
		dataToBeSent[i] = data[i];
		
		
	}
	
	//console.log(dataToBeSent);	
	endpoints[1].transfer(dataToBeSent, function(err, data){
	if(!err){
	}
		else{
	 		console.log(error);
		}

	});


});
readRawMutualData(reader, dataToBeSent, endpoints);

//readTouchEndPoints(touchEndpoints);
app.get('/', function(req, res){
	res.sendFile(__dirname + '/index.html');
});

io.on('connection', function(socket){
	socket.on('disconnect', function(){
		console.log('client disconnected');
	});
		
});

http.listen(3000, function(){
	console.log('Listening on *:3000');
});


