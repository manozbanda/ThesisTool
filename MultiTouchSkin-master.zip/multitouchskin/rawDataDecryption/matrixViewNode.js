var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var express = require('express');

var usb = require('usb');
var fs = require('fs');
var csv = require('ya-csv');
var os = require('os');
var reader = csv.createCsvFileReader('write_commands.csv', {
    'separator': ',',
    'quote': '"',
    'escape': '"',       
    'comment': '',
});

var NUM_RX_LINES = 27;
var NUM_TX_LINES = 19;
var dataToBeSent = new Uint8Array(64);
var mutualDataTable = new Array();
var rxLines = new Array();

function initMutualDataTable(){
	for(var i = 0 ; i < NUM_TX_LINES; i++){
		for(var j = 0 ; j < NUM_RX_LINES; j++){
			rxLines[j] = 0;
		}
		mutualDataTable.push(rxLines);
		rxLines = [];
	}
}

function getRandomInt(min, max){
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min)) + min;
}

function generateRandomMutualDataTable(){
	for(var i = 0 ; i < NUM_TX_LINES; i++){
		for(var j = 0 ; j < NUM_RX_LINES; j++){
			mutualDataTable[i][j] = getRandomInt(0,512);
		}
	}
}

initMutualDataTable();
console.log(mutualDataTable);
var mtchController = usb.findByIds(1240, 2517);
mtchController.open();
var endpoints = mtchController.interfaces[1].endpoints;
var touchEndpoints = mtchController.interfaces[0].endpoints;
console.log(touchEndpoints);

//detach the system USB driver if the USB interfaces are busy
if(mtchController.interfaces[0].isKernelDriverActive()){
	console.log("Touch Data Endpoints Interface Busy");
	mtchController.interfaces[0].detachKernelDriver();
	mtchController.interfaces[0].claim();
}


if(mtchController.interfaces[1].isKernelDriverActive()){
	console.log("Raw data endpoints busy");
	mtchController.interfaces[1].detachKernelDriver();
	mtchController.interfaces[1].claim();

}

//claim the USB interfaces
mtchController.interfaces[0].claim();
mtchController.interfaces[1].claim();

endpoints[0].transferType = usb.LIBUSB_TRANSFER_TYPE_BULK;
endpoints[1].transferType = usb.LIBUSB_TRANSFER_TYPE_BULK;

touchEndpoints[0].transferType = usb.LIBUSB_TRANSFER_TYPE_BULK;



function readRawMutualData(reader, dataToBeSent, endpoints){
	reader.addListener('data', function(data){
		for(var i = 0 ; i < 64; i++){
			dataToBeSent[i] = data[i];	
		}
		endpoints[1].transfer(dataToBeSent, function(err, data){
		if(!err){
		}
			else{
				console.log(error);
			}

		});
	});
	
	endpoints[0].startPoll(1 , 64);
	endpoints[0].on('data', function(data){
	dataToBeSent = data;
	console.log(JSON.stringify(dataToBeSent));
	function findData(element){
		return element == 0xc3;
	}
	var index = data.findIndex(findData);
	var sizeOfPacket = data[index - 1] & 0x1f;
	if( (index != -1) && (index != 2) && (sizeOfPacket <= 9)){
		if( (( (sizeOfPacket - 3) % 2) == 0) && (data[index + 1] < 0x1a) && (data[index + 2] < 0x13) ){
			
			var rxLocation = data[++index];
			var txLocation = data[++index];
			for(var k = 0 ; k < (sizeOfPacket - 3) / 2 ; k++){
				var LSB = data[index + 1];
				var MSB = data[index + 2];
				var value = MSB + LSB;
				mutualDataTable[txLocation][rxLocation] = parseInt(value);
				
				index = index + 2;
				txLocation++;
			}
		
		}
	}
	
	
	//console.log(dataToBeSent);
	//io.sockets.emit('raw data', JSON.stringify(data));
	//console.log(JSON.stringify(data));	
	});
}

readRawMutualData(reader, dataToBeSent, endpoints);



setInterval(function(){
	//generateRandomMutualDataTable();
	io.sockets.emit('raw data', JSON.stringify(mutualDataTable))},5);

io.on('connection', function(socket){
	socket.on('disconnect', function(){
		console.log('client disconnected');
	});
		
});





app.use('/images', express.static(__dirname + '/images'));
app.use('/css', express.static(__dirname + '/css'));
app.use('/js', express.static(__dirname + '/js'));

app.get('/', function(req, res){
	res.sendFile(__dirname + '/index.html');
});

http.listen(3000, function(){
	console.log('Listening on *:3000');
});
