// Your code here!
function initMutualDataGrid(){
    var NUM_RX_CHANNELS = 27;
    var NUM_TX_CHANNELS = 19;
    
    for(var i = 1 ; i <= NUM_TX_CHANNELS; i++){
        var tx = "tx" + i;
        var txDiv = document.getElementById(tx);
        for(var j = 0 ; j < NUM_RX_CHANNELS ; j++){
            var newDiv = document.createElement('div');
            newDiv.id = j;
            newDiv.style.width = '3.5%';
            newDiv.style.height = '35px';
            newDiv.style.background = 'gray';
            newDiv.textContent = '000';
            txDiv.appendChild(newDiv);
        
        }
      
    }

  /*  var tx = "tx" + 17;
    var txDiv = document.getElementById(tx);
    for(var j = 0 ; j < NUM_RX_CHANNELS ; j++){
        var newDiv = document.createElement('div');
        newDiv.id = j;
        newDiv.style.width = '3.5%';
        newDiv.style.height = '35px';
        newDiv.style.background = 'gray';
        newDiv.textContent = '000';
        txDiv.appendChild(newDiv);
    
    }
     // var br = document.createElement('br');
    tx = "tx" + 2;
    txDiv = document.getElementById(tx);
    for(var j = 0 ; j < NUM_RX_CHANNELS ; j++){
        var newDiv = document.createElement('div');
        newDiv.id = j;
        newDiv.style.width = '3.5%';
        newDiv.style.height = '35px';
        newDiv.style.background = 'gray';
        newDiv.textContent = '000';
        txDiv.appendChild(newDiv);
    
    }*/
}