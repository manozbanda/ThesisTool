
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;

import com.opencsv.CSVReader;

import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

public class FXController implements Initializable{

	@FXML
	ImageView rawImage;

	@FXML
	ImageView filteredImage;

	@FXML
	 ImageView blobDetection;

	@FXML
	Button loadFrames;

	@FXML
	Button next_frameButton;

	@FXML
	Text debug_text;

	@FXML
	Button saveFrameButton;

	@FXML
	CheckBox tx0Checkbox;

	@FXML
	CheckBox tx1Checkbox;

	@FXML
	CheckBox tx2Checkbox;

	@FXML
	CheckBox tx3Checkbox;

	@FXML
	CheckBox tx4Checkbox;

	@FXML
	CheckBox tx5Checkbox;
	
	@FXML
	Button reconnect;

	private ScheduledExecutorService timer;
	private ScheduledExecutorService dataGeneratorTimer;

	static CSVReader reader = null;
	static final float BINARY_IMAGE_THRESHOLD = 0.40f;
	int[] filteredData = new int[NUM_ROWS * NUM_COLUMNS];
	static int NUM_ROWS = 6;
	static int NUM_COLUMNS = 6;

	static String pathToCSVFile = "data/Gestures/";
	static String name_of_CSVFile = "G00.csv";
	String test_current_pressure_level = "P6";

	static int SAMPLE_SIZE_FOR_INTENSITY_VALUES = 4;
	static float[] MAX_INTENSITY_VALUES = new float[SAMPLE_SIZE_FOR_INTENSITY_VALUES];

	int LOW_PASS_FILTER_CUTOFF = 30;
	int MAX_VALUE_OF_RAW_DATA = 300;

	int currentFrameNumber = 0;

	BufferedImage interpolatedImage;
	BufferedImage binaryImage;
	BufferedImage blobImage;

	Image interpolatedImg;
	Image binaryImg;
	Image blobImg;
	
	static int NUM_RX_CHANNELS = 27;
	static int NUM_TX_CHANNELS = 19;
	DataGenerator dataGenerator;
	static int[][]mutualDataTable = new int[NUM_TX_CHANNELS][NUM_RX_CHANNELS];
	SocketIOClient piConnection;


	/* (non-Javadoc)
	 * @see javafx.fxml.Initializable#initialize(java.net.URL, java.util.ResourceBundle)
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

		System.out.println("Initializing");
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		loadCSVFile(pathToCSVFile + name_of_CSVFile);

		piConnection = new SocketIOClient();
		piConnection.createSocket();
		Utils.initializeArffFile();
		dataGenerator = new DataGenerator(NUM_RX_CHANNELS, NUM_TX_CHANNELS);
		
		/*Runnable randomDataGenerator = new Runnable() {
			@Override
			public void run() {
				mutualDataTable = dataGenerator.generateRandomMutualTable();
			}
		};
		
		this.dataGeneratorTimer = Executors.newSingleThreadScheduledExecutor();
		this.dataGeneratorTimer.scheduleAtFixedRate(randomDataGenerator, 0, 5, TimeUnit.MILLISECONDS);*/



	}

	/*Takes the path of the CSV file as an argument and loads a CSV reader to read the data*/
	public void loadCSVFile(String pathToFile){
		try {
			reader = new CSVReader(new FileReader(pathToFile));
			//reader = new CSVReader(new FileReader("data/multi-touch-pressure_adi_pilot/pressure_body_test_level6_v2.csv"));
			try {
				String[] sample = reader.readNext();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}




	 /* Update the {@link ImageView} in the JavaFX main thread
	 *
	 * @param view
	 *            the {@link ImageView} to update
	 * @param image
	 *            the {@link Image} to show
	 */
	private void updateImageView(ImageView view, Image image)
	{
		Utils.onFXThread(view.imageProperty(), image);
	}
	public void debug_print_mutualTable() {
		for(int i  = 0 ; i < NUM_TX_CHANNELS; i++) {
			for(int j = 0 ; j < NUM_RX_CHANNELS; j++) {
				System.out.println(mutualDataTable[i][j] + ", ");
			}
			System.out.println();
		}
	}
	
	@FXML
	protected void loadRealTimeData(ActionEvent event) {
		System.out.println("Rendering Real Time data");
		
		Runnable frameRenderer = new Runnable() {
			@Override
			public void run() {
				
			//	mutualDataTable = piConnection.getMutualDataTable();
				//debug_print_mutualTable();
				
			//	mutualDataTable = dataGenerator.generateRandomMutualTable();
				interpolatedImage = ImageProcessingUtils.createImage(NUM_RX_CHANNELS, NUM_TX_CHANNELS, mutualDataTable);
				interpolatedImage = ImageProcessingUtils.upScaleImage(interpolatedImage, 10, 10, BufferedImage.TYPE_3BYTE_BGR);
				interpolatedImg = SwingFXUtils.toFXImage(interpolatedImage, null);

				updateImageView(rawImage, interpolatedImg);
				
				binaryImage = ImageProcessingUtils.maskAndCreateBinaryImage(interpolatedImage, BINARY_IMAGE_THRESHOLD);
				binaryImg = SwingFXUtils.toFXImage(binaryImage, null);
			    updateImageView(filteredImage, binaryImg);
				
			}
		};
		
		this.timer = Executors.newSingleThreadScheduledExecutor();
		this.timer.scheduleAtFixedRate(frameRenderer, 0, 5, TimeUnit.MILLISECONDS);
		
	}
	
	@FXML
	protected void reconnectToServer(ActionEvent event) {
		System.out.println("Re-Connecting");
		piConnection.createSocket();
		
	}

	@FXML
	protected void loadOfflineData(ActionEvent event){

		System.out.println("Button Pressed");


		Runnable frameRenderer = new Runnable(){
			@Override
			public void run(){

				//filteredData = generateRandomData();
				filteredData = readNextFrame();
				if(filteredData != null){

					currentFrameNumber++;
					interpolatedImage = Utils.createImage(6, 6, filteredData);
					interpolatedImage = Utils.upScaleImage(interpolatedImage, 10, 10, BufferedImage.TYPE_3BYTE_BGR);
					interpolatedImg = SwingFXUtils.toFXImage(interpolatedImage, null);

					updateImageView(rawImage, interpolatedImg);

					binaryImage = Utils.maskAndCreateBinaryImage(interpolatedImage, BINARY_IMAGE_THRESHOLD);
					binaryImg = SwingFXUtils.toFXImage(binaryImage, null);
				    updateImageView(filteredImage, binaryImg);

				  /*  byte[] pixels = ((DataBufferByte) binaryImage.getRaster().getDataBuffer()).getData();
				    if(pixels != null){
				    	Mat mat = new Mat(binaryImage.getHeight(), binaryImage.getWidth(), CvType.CV_8UC3);
					    mat.put(0, 0, pixels);
					    float[] blobDetails = OpenCVBlobDetector.performBlobDetection(mat);
					    for(int i = 0 ; i < blobDetails.length; i++)
							System.out.println(blobDetails[i]);
				    }*/


				//    Utils.createWekaDataInstance(MAX_INTENSITY_VALUES, test_current_pressure_level);

				    // Utils.dumpImage(img, "binary_image", "jpg");

				  //   byte[] srcData = ((DataBufferByte) img.getData().getDataBuffer()).getData();
				     //img = Utils.performBlobDetection(img);
				     //blobImg = SwingFXUtils.toFXImage(img, null);
				     //updateImageView(blobDetection, blobImg);

				}
				else{
					timer.shutdown();
					System.out.println("Finished all the frames \n");
				}


			}

		};


		this.timer = Executors.newSingleThreadScheduledExecutor();
		this.timer.scheduleAtFixedRate(frameRenderer, 0, 10, TimeUnit.MILLISECONDS);

		//displayAllFrames();
	}



	public int[] readNextFrame(){
		String[] nextLine;
		String intensityValues = "";

		float[]data = new float[36];
		int[] filteredData = new int[36];
		int j = 0;

		try {
			nextLine = reader.readNext();


			if(nextLine != null){
				for(int i = 7 ; i < nextLine.length - 1; i++){
					data[j] = Integer.parseInt(nextLine[i]);
					j++;
				}
			}
			else{
				return null;
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//low-pass filter to remove noise and the calculate the highest intensities
		data = Utils.filterData(data, LOW_PASS_FILTER_CUTOFF);

		if(tx0Checkbox.isSelected() == true){
			//filter noise in TX0
			data[0] = 0;
			data[6] = 0;
			data[12] = 0;
			data[18] = 0;
			data[24] = 0;
			data[30] = 0;
		}

		if(tx1Checkbox.isSelected() == true){
			//filter noise in TX0
			data[1] = 0;
			data[7] = 0;
			data[13] = 0;
			data[19] = 0;
			data[25] = 0;
			data[31] = 0;
		}

		if(tx2Checkbox.isSelected() == true){
			//filter noise in TX0
			data[2] = 0;
			data[8] = 0;
			data[14] = 0;
			data[20] = 0;
			data[26] = 0;
			data[32] = 0;
		}

		if(tx3Checkbox.isSelected() == true){
			//filter noise in TX0
			data[3] = 0;
			data[9] = 0;
			data[15] = 0;
			data[21] = 0;
			data[27] = 0;
			data[33] = 0;
		}

		if(tx4Checkbox.isSelected() == true){
			//filter noise in TX0
			data[4] = 0;
			data[10] = 0;
			data[16] = 0;
			data[22] = 0;
			data[28] = 0;
			data[34] = 0;
		}

		if(tx5Checkbox.isSelected() == true){
			//filter noise in TX5
			data[5] = 0;
			data[11] = 0;
			data[17] = 0;
			data[23] = 0;
			data[29] = 0;
			data[35] = 0;
		}




		MAX_INTENSITY_VALUES = Utils.calculateHighestIntensities(data, SAMPLE_SIZE_FOR_INTENSITY_VALUES);
		//float averageIntensity = Utils.calculateAverage(MAX_INTENSITY_VALUES);

		/*for(int i = 0 ; i < SAMPLE_SIZE_FOR_INTENSITY_VALUES; i++){
			System.out.println(MAX_INTENSITY_VALUES[i] + "\t");
			//debug_text.setText(MAX_INTENSITY_VALUES[i] + "\t");
			intensityValues += MAX_INTENSITY_VALUES[i] + "\t";


		}*/
		System.out.println(MAX_INTENSITY_VALUES[0]);
	//	System.out.println(averageIntensity);
		//System.out.println(averageIntensity + " , " + test_current_pressure_level);
		//System.out.println("\n");
		Utils.updateTextOnFXThread(debug_text, intensityValues + "\n");

		for(int i = 0 ; i < data.length; i++){
			filteredData[i] = (int) ( (data [i] / MAX_VALUE_OF_RAW_DATA) * 255) ;
		}

		return filteredData;

	}


	@FXML
	public void loadNextFrame (ActionEvent event){

		System.out.println("Loading Next Frame");

		filteredData = readNextFrame();
		if(filteredData != null){
			currentFrameNumber++;

			interpolatedImage = Utils.createImage(6, 6, filteredData);
			interpolatedImage = Utils.upScaleImage(interpolatedImage, 10, 10, BufferedImage.TYPE_INT_RGB);
			interpolatedImg = SwingFXUtils.toFXImage(interpolatedImage, null);

			updateImageView(rawImage, interpolatedImg);

			binaryImage = Utils.maskAndCreateBinaryImage(interpolatedImage, BINARY_IMAGE_THRESHOLD);
		    binaryImg = SwingFXUtils.toFXImage(binaryImage, null);
		    updateImageView(filteredImage, binaryImg);

		    //Utils.createWekaDataInstance(MAX_INTENSITY_VALUES, test_current_pressure_level);

		     //Utils.dumpImage(img, "binary_image", "jpg");

		  /*   byte[] srcData = ((DataBufferByte) img.getData().getDataBuffer()).getData();
		     img = Utils.performBlobDetection(img);
		     rawimage = SwingFXUtils.toFXImage(img, null);
		     updateImageView(blobDetection, rawimage);*/

		}
		else{
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Done");
			alert.setContentText("Finished All frames!!");
			alert.showAndWait();
		}

	}


	@FXML
	public void saveFramePressed(ActionEvent event){
		System.out.println("Dumping Image");
		Utils.dumpImage(interpolatedImage, "image_dumps/" + name_of_CSVFile+ "_interpolatedImage_frame" + currentFrameNumber, "jpg");
		Utils.dumpImage(binaryImage, "image_dumps/" + name_of_CSVFile+ "_binaryImage_frame" + currentFrameNumber, "jpg");
		System.out.println("Dumped the image in image_dumps folder");

	/*	System.out.println("Performing Blob Detection\n");
		float[] blobDetails = OpenCVBlobDetector.performBlobDetection("image_dumps/" + name_of_CSVFile+ "_binaryImage_frame" + currentFrameNumber, "jpg");
		for(int i = 0 ; i < blobDetails.length; i++)
		System.out.println(blobDetails[i]);*/


	}

	/*public static void performBlobDetection(BufferedImage img){


		//	Mat orig = bufferedImageToMat(img);
	       // Mat orig = Highgui.imread("E:\\PhotoIn.jpg",Highgui.IMREAD_GRAYSCALE);

	        Mat MatOut= new Mat();

	  //      MatOut = Mat.zeros(orig.size(), CvType.CV_8UC3);
	        FeatureDetector blobDetector;

	        blobDetector = FeatureDetector.create(FeatureDetector.SIMPLEBLOB);
	    //    blobDetector.write("blob_params.xml");
	        blobDetector.read("blob_params.xml");

	        MatOfKeyPoint keypoints1 = new MatOfKeyPoint();


	        blobDetector.detect(orig,keypoints1);

	        org.opencv.core.Scalar cores = new org.opencv.core.Scalar(0,0,255);

	        org.opencv.features2d.Features2d.drawKeypoints(orig,keypoints1,MatOut,cores,4);
	        Size numKeypoints = keypoints1.size();

	        //org.opencv.features2d.Features2d.drawKeypoints(orig,keypoints1,MatOut,cores,org.opencv.features2d.Features2d.DRAW_RICH_KEYPOINTS);

	        Imgcodecs.imwrite("output.jpg", MatOut);
	}
	*/

	public static Mat bufferedImageToMat(BufferedImage bi) {
		  Mat mat = new Mat(bi.getHeight(), bi.getWidth(), CvType.CV_8UC1);
		  byte[] pixels = ((DataBufferByte) bi.getRaster().getDataBuffer()).getData();
		//  byte[] data = ((DataBufferByte) bi.getRaster().getDataBuffer()).getData();
		  mat.put(0, 0, pixels);
		  return mat;
		}


}
