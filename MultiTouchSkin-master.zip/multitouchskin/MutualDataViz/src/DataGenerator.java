import java.util.Random;

public class DataGenerator {
	
	int[][]  mutualDataTable;
	int NUM_RX;
	int NUM_TX;
	public DataGenerator(int numRX, int numTX) {
		NUM_RX = numRX;
		NUM_TX = numTX;
		mutualDataTable = new int[numTX][numRX];
		for(int i = 0 ; i < numTX; i++) {
			for (int j = 0 ; j < numRX; j++) {
				mutualDataTable[i][j] = 0;
			}
		}
	}
	
	public int[][]generateRandomMutualTable() {
		 Random randomGenerator = new Random();
		
		for(int i = 0 ; i < NUM_TX; i++) {
			for (int j = 0 ; j < NUM_RX; j++) {
				mutualDataTable[i][j] = randomGenerator.nextInt(512);;
			}
		}
		return mutualDataTable;
	}
	
	public int[][]testTableData(){
		
		if(mutualDataTable == null)
			mutualDataTable = new int[NUM_TX][NUM_RX];
		
	/*	mutualDataTable[0][0] = 5;
		mutualDataTable[0][1] = 113;
		mutualDataTable[0][2] = 116;
		mutualDataTable[0][3] = 3;
		mutualDataTable[0][4] = 0;
		mutualDataTable[0][5] = 7;*/
		
		
		mutualDataTable[1][0] = 5;
		mutualDataTable[1][1] = 48;
		mutualDataTable[1][2] = 112;
		mutualDataTable[1][3] = 28;
		mutualDataTable[1][4] = 0;
		mutualDataTable[1][5] = 8;
		
	/*	mutualDataTable[2][0] = 3;
		mutualDataTable[2][1] = 17;
		mutualDataTable[2][2] = 65;
		mutualDataTable[2][3] = 18;
		mutualDataTable[2][4] = 0;
		mutualDataTable[2][5] = 3;
		
		mutualDataTable[3][0] = 3;
		mutualDataTable[3][1] = 228;
		mutualDataTable[3][2] = 88;
		mutualDataTable[3][3] = 11;
		mutualDataTable[3][4] = 0;
		mutualDataTable[3][5] = 0;
		
		mutualDataTable[4][0] = 3;
		mutualDataTable[4][1] = 43;
		mutualDataTable[4][2] = 0;
		mutualDataTable[4][3] = 0;
		mutualDataTable[4][4] = 0;
		mutualDataTable[4][5] = 0;*/
		
		/*mutualDataTable[5][0] = 0;
		mutualDataTable[5][1] = 0;
		mutualDataTable[5][2] = 0;
		mutualDataTable[5][3] = 0;
		mutualDataTable[5][4] = 0;
		mutualDataTable[5][5] = 0;*/
		
		return mutualDataTable;
		
	}
	
	
	public int[][] getMutualDataTable(){
		return mutualDataTable;
	}

}
