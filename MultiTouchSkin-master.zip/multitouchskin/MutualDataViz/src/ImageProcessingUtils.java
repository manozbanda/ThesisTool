import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;

public class ImageProcessingUtils {
	
	public static BufferedImage createImage(int img_width, int img_height, int[][] pixelValues){
		int i = 0;
		BufferedImage img = new BufferedImage(img_width, img_height, BufferedImage.TYPE_3BYTE_BGR);
		for(int y = 0 ; y < img_height; y++){
			for(int x = 0 ; x < img_width; x++){
				int r = (int) pixelValues[y][x];
				int g = (int) pixelValues[y][x];
				int b = (int) pixelValues[y][x];
				
				int p =  (r<<16) | (g<<8) | b;
				
				img.setRGB(x, y, p);
			}
		}
		return img;
	}
	
	public static BufferedImage upScaleImage(BufferedImage img, int scaleX, int scaleY, int imageType){

		int w = img.getWidth();
		int h = img.getHeight();
		BufferedImage after = new BufferedImage(w* scaleX, h* scaleY, imageType);
		AffineTransform at = new AffineTransform();
		at.scale(10.0, 10.0);
		AffineTransformOp scaleOp = 
		   new AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR);
		after = scaleOp.filter(img, after);
		
		return after;
		
	}
	
public static BufferedImage maskAndCreateBinaryImage(BufferedImage img, float binaryImageThreshold){
		
		BufferedImage maskedImage = new BufferedImage(img.getWidth(), img.getHeight(), img.getType());
		maskedImage = img;
		float highestIntensityValue = 0, currentValue = 0;
		//System.out.println("Width: " + img.getWidth() + "Height: " + img.getHeight());
		
		//masking the image. Noisy pixels i.e Pixels less than 10% (i.e 0.1*255) are removed by masking them to 0
		for(int i  = 0 ; i < img.getHeight() - 1; i++){
			for(int j = 0 ; j < img.getWidth()- 1; j++){
				//System.out.println("i: " + i + "j:" + j);
				int pixelValue = img.getRGB(j, i);
				
				int r = (pixelValue >> 16) & 0xFF;
				int g = (pixelValue >> 8) & 0xFF;
				int b = (pixelValue & 0xFF);
				
				if(r < 25){
					maskedImage.setRGB(j, i, 0);
				}
				else{
						currentValue = r;
						if(currentValue > highestIntensityValue){
							highestIntensityValue = currentValue;
						}
				}					
			}
		}
		
		/*Scaling factors is calculated to scale the rest of the image on a linear scale, 
		 * i.e. the higher pixel value is made 255 and the other pixels are scaled accordnigly.*/
		
		
		float scalingFactor = (float) ( 255.0 / highestIntensityValue );
		
		for(int i  = 0 ; i < img.getHeight() - 1; i++){
			for(int j = 0 ; j < img.getWidth() - 1; j++){
				int pixelValue = img.getRGB(j, i);
				
				int r = (pixelValue >> 16) & 0xFF;
				int g = (pixelValue >> 8) & 0xFF;
				int b = (pixelValue & 0xFF);
				
				int new_r =  (int) (r * scalingFactor);
				int new_g = (int)  (g * scalingFactor);
				int new_b = (int)  (b * scalingFactor);
					
				int p =  (new_r<<16) | (new_g<<8) | new_b;
					
				maskedImage.setRGB(j, i, p);;
				
					
			}
		}
		
		

		for(int i  = 0 ; i < img.getHeight() - 1; i++){
			for(int j = 0 ; j < img.getWidth() - 1; j++){
				int pixelValue = img.getRGB(j, i);
				
				int r = (pixelValue >> 16) & 0xFF;
				int g = (pixelValue >> 8) & 0xFF;
				int b = (pixelValue & 0xFF);
				
				if(r < (255 * binaryImageThreshold)){
					maskedImage.setRGB(j, i, 0);
				}
				else{
					int new_r = (int) 255;
					int new_g = (int) 255;
					int new_b = (int) 255;
					
					int p =  (new_r<<16) | (new_g<<8) | new_b;
					
					maskedImage.setRGB(j, i, p);;
				}
					
			}
		}
	
		return maskedImage;
		
	}

	/*Low pass filter to filter out all the noise. Filters out all the values that are above a cut-off making them zero. 
	 * 
	 */
	public static float[][] filterData(float[][] inputData, int numRX, int numTX, float cutoffValue){
		
		for(int i = 0 ; i < numTX; i++){
			for(int j = 0 ; j < numRX; j++) {
				if(inputData[i][j] > cutoffValue){
					inputData[i][j] = 0;
				}
			}
		}
		return inputData;
	}


}
